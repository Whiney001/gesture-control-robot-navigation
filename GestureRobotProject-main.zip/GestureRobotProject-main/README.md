# GestureRobotProject
AI-powered gesture control system for robot navigation using MediaPipe and ROS
