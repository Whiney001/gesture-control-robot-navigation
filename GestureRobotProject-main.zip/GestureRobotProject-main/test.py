print("Hello! Python is working!")
print("My name is Winnie")
print("I'm starting my gesture robot project!")